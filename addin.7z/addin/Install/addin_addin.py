
import arcpy
from arcpy import env
import pythonaddins

class ComboBoxClass7(object):
    """Implementation for addin_addin.combobox (ComboBox)"""
    def __init__(self):
        self.items = ["item1", "item2"]
        self.editable = True
        self.enabled = True
        self.dropdownWidth = 'WWWWWW'
        self.width = 'WWWWWW'
    def onSelChange(self, selection):
        pass
    def onEditChange(self, text):
        pass
    def onFocus(self, focused):
        pass
    def onEnter(self):
        pass
    def refresh(self):
        pass

class ExplosionButtonClass(object):
    """Implementation for addin_addin.explosionbutton (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pass
        
# Implementation of OnClick method of Button's class
    def onClick(self):
        #pythonaddins.MessageBox("Hello world", "Hello")
        combobox.items = ["Hello everyone"]
        combobox.items.append("Hello you")
        
        #arcpy.env.workspace = "M:/Python_Advanced/albertsurface"
  
        try:
            try:
                arcpy.ImportToolbox("M:/Python_Advanced/albertsurface/Models.tbx","models")
                combobox.items = ["Work is importing"]
                with pythonaddins.ProgressDialog as dialog:
                    dialog.title = "Progress Dialog"
                    dialog.description = "Copying a large feature class."
                arcpy.AddMessage("Toolbox is importing")
            except arcpy.ExecuteError as e:
                print(arcpy.GetMessages())
                print("Import toolbox error", e)
                tb = sys.exc_info()[2]
                tbinfo = traceback.format_tb(tb)[0]
                arcpy.AddError(tbinfo)

            try:
                object = pythonaddins.GPToolDialog("M:/Python_Advanced/albertsurface/Models.tbx","Explosion")
                arcpy.AddMessage("Model is running")
                combobox.items = ["Work is processing"]
            except arcpy.ExecuteError as e:
                tb = sys.exc_info()[2]
                tbinfo = traceback.format_tb(tb)[0]
                arcpy.AddError(tbinfo)
                print("Model run error", e)
        except Exception as e:
            print(e)
            
            