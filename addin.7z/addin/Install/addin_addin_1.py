import arcpy
from arcpy import env
import pythonaddins

class ExplosionButtonClass(object):
    """Implementation for addin_addin.explosionbutton (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pass
        
# Implementation of OnClick method of Button's class
    def onClick(self):
        #pythonaddins.MessageBox("Hello world", "Hello")
        pythonaddins.combobox("Hello everyone")
       
        #arcpy.env.workspace = "M:/Python_Advanced/albertsurface"
  
        try:
            try:
                arcpy.ImportToolbox("M:/Python_Advanced/albertsurface/Models.tbx","models")
                with pythonaddins.ProgressDialog as dialog:
                    dialog.title = "Progress Dialog"
                    dialog.description = "Copying a large feature class."
                arcpy.AddMessage("Toolbox is importing")
            except arcpy.ExecuteError as e:
                print(arcpy.GetMessages())
                print("Import toolbox error", e)
                tb = sys.exc_info()[2]
                tbinfo = traceback.format_tb(tb)[0]
                arcpy.AddError(tbinfo)

            try:
                object = pythonaddins.GPToolDialog("M:/Python_Advanced/albertsurface/Models.tbx","Explosion")
                arcpy.AddMessage("Model is running")
            except arcpy.ExecuteError as e:
                tb = sys.exc_info()[2]
                tbinfo = traceback.format_tb(tb)[0]
                arcpy.AddError(tbinfo)
                print("Model run error", e)
        except Exception as e:
            print(e)
            
            
        """
        # Get the current map document and the first data frame.
        mxd = arcpy.mapping.MapDocument('current')
        df = arcpy.mapping.ListDataFrames(mxd)[0]
        # Call the zoomToSelectedFeatures() method of the data frame class
        df.zoomToSelectedFeatures()
        pythonaddins.MessageBox("Hello world", "Hello")
        """